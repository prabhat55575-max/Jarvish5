# DeviceGuard — Motion Anti-Theft Alarm

## What it does
Arms the phone/tablet and monitors accelerometer (+ gyroscope if available).
On confirmed movement it triggers a loud looping alarm, vibration, high-priority notification, and full-screen alarm UI.

## What it does NOT do
- No Bluetooth / BLE / UWB / GPS / Wi-Fi proximity / 3-meter distance detection.
- **This app detects physical movement/handling using device sensors. It does not guarantee detection of every touch and does not measure exact distance.**
- Accelerometer/gyroscope detect motion, not a stationary finger touch.

## Installation / Android Studio setup
1. Open Android Studio (Hedgehog+), Open `DeviceGuardMotionAlarm/`.
2. Let Gradle sync (AGP 8.5.2, Kotlin 1.9.24, compileSdk/targetSdk 35, minSdk 26, JVM 17).
3. Build > Build APK(s).

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## How to arm
1. Grant notification permission (Android 13+).
2. Tap ARM DEVICE, set phone down, wait ~1.5s baseline. "Protection active. Keep the device still."
3. On movement: alarm fires. Tap STOP ALARM (or notification action).

## Test
TEST ALARM works without arming: plays sound, vibrates, shows alarm UI and notification.

## Sensitivity
Settings > Sensitivity: LOW / MEDIUM (default) / HIGH. HIGH is more sensitive, more false alarms.
Confirmation duration 300–3000ms (default 700ms): movement must persist this long.

## Troubleshooting
- No alarm: raise alarm-stream volume, check POST_NOTIFICATIONS granted, disable battery optimization for the app.
- False alarms: lower sensitivity, raise confirmation duration, place on stable surface.
- Gyroscope missing: app still works on accelerometer.

## Permissions
VIBRATE, FOREGROUND_SERVICE, FOREGROUND_SERVICE_SPECIAL_USE, POST_NOTIFICATIONS only.

package com.deviceguard.motion

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("deviceguard_prefs", Context.MODE_PRIVATE)

    private val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    private val securePrefs: SharedPreferences = try {
        EncryptedSharedPreferences.create(context, "deviceguard_secure",
            masterKey, EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    } catch (e: Exception) { prefs }

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings

    private fun load(): AppSettings = AppSettings(
        sensitivity = Sensitivity.valueOf(prefs.getString("sensitivity","MEDIUM")!!),
        confirmationMs = prefs.getInt("confirmationMs", 700),
        vibrationEnabled = prefs.getBoolean("vibration", true),
        soundEnabled = prefs.getBoolean("sound", true),
        pinEnabled = prefs.getBoolean("pinEnabled", false)
    )
    private fun save(s: AppSettings) {
        prefs.edit().putString("sensitivity", s.sensitivity.name)
            .putInt("confirmationMs", s.confirmationMs)
            .putBoolean("vibration", s.vibrationEnabled)
            .putBoolean("sound", s.soundEnabled)
            .putBoolean("pinEnabled", s.pinEnabled).apply()
        _settings.value = s
    }
    fun update(s: AppSettings) = save(s)
    fun reset() = save(AppSettings())
    fun setPin(pin: String) { securePrefs.edit().putString("pin", pin).apply() }
    fun getPin(): String? = securePrefs.getString("pin", null)
    fun hasPin(): Boolean = getPin() != null
}

package com.deviceguard.motion

enum class Sensitivity { LOW, MEDIUM, HIGH }
enum class ProtectionState { OFF, ARMING, ACTIVE, ALARM }

data class AppSettings(
    val sensitivity: Sensitivity = Sensitivity.MEDIUM,
    val confirmationMs: Int = 700,
    val vibrationEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val pinEnabled: Boolean = false
)

package com.deviceguard.motion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StopAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmController.stop()
        val s = Intent(context, MotionService::class.java).setAction(MotionService.ACTION_STOP_ALARM)
        context.startService(s)
    }
}

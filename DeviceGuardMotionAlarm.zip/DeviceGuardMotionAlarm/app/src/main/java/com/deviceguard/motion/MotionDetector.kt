package com.deviceguard.motion

import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

class MotionDetector(
    private var sensitivity: Sensitivity = Sensitivity.MEDIUM,
    private var confirmationMs: Int = 700
) {
    private val accelWindow = ArrayDeque<Float>()
    private var abnormalStart: Long = 0L
    private var lastTrigger: Long = 0L
    private val windowSize = 8

    // thresholds on movement score (m/s^2 approx after gravity removal + gyro contribution)
    private fun threshold(): Float = when (sensitivity) {
        Sensitivity.LOW -> 2.2f
        Sensitivity.MEDIUM -> 1.2f
        Sensitivity.HIGH -> 0.6f
    }

    fun updateSettings(s: Sensitivity, c: Int) { sensitivity = s; confirmationMs = c }

    /** Returns movement score; call onTrigger when confirmed. */
    fun onSensor(ax: Float, ay: Float, az: Float, gx: Float, gy: Float, gz: Float,
                 hasGyro: Boolean, now: Long, cooldownMs: Long = 3000L,
                 onConfirmed: () -> Unit): Float {
        val mag = sqrt(ax*ax + ay*ay + az*az)
        val linear = abs(mag - SensorManager.GRAVITY_EARTH)
        val gyroMag = if (hasGyro) sqrt(gx*gx + gy*gy + gz*gz) else 0f
        val score = linear + gyroMag * 1.5f
        accelWindow.addLast(score)
        if (accelWindow.size > windowSize) accelWindow.removeFirst()
        val smooth = accelWindow.average().toFloat()
        if (smooth > threshold()) {
            if (abnormalStart == 0L) abnormalStart = now
            if (now - abnormalStart >= confirmationMs && now - lastTrigger > cooldownMs) {
                lastTrigger = now
                abnormalStart = 0L
                onConfirmed()
            }
        } else {
            abnormalStart = 0L
        }
        return smooth
    }

    fun motionLevel(score: Float): String = when {
        score < threshold()*0.5f -> "LOW"
        score < threshold() -> "MEDIUM"
        else -> "HIGH"
    }

    fun reset() { accelWindow.clear(); abnormalStart = 0L }
}
